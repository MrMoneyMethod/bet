# Prediction engine v1: experimental and uncalibrated

Implementation: `src/core.cpp`. Model identifier: `weighted-bootstrap-v1-experimental`.

This is a transparent research baseline, not trained ML. Coefficients are documented heuristics, not fitted or proven optimal. No out-of-sample profitability, calibration, accuracy, closing-line-value or win-rate claim is made. Synthetic demo results cannot validate anything.

## Player statistics

1. Select at most the 60 newest historical games with at least 5 minutes played, strictly before the target start. Require at least 12 games. DNPs/very-low-minute games are excluded: this can bias the sample toward active participation and must not be mistaken for a fully injury-conditioned distribution.
2. Weight historical game index `i` with `exp(-0.045 × i)`, multiplied by `1.15` for the same home/away location. These constants are fixed heuristics.
3. Estimate minutes as `0.7 × last-5 mean + 0.3 × weighted historical mean`, capped at 6–42. Explicit user overrides (0.1–48) are exposed.
4. Adjust the historical stat rate by `(team pace + opponent pace)/2 / historical team pace`, clipped to 0.85–1.15. If player-specific historical pace is not supplied, the current team pace is used as an **explicit approximation**; historical opponent pace for every sample game is not reconstructed. Off-season pace/role changes remain a limitation.
5. Draw 8,192 weighted historical **whole stat vectors**. Scale all dimensions by projected minutes / sampled minutes, pace ratio and a shared mean-one lognormal perturbation with log-SD `0.08`. Round each category to a nonnegative integer.
6. Compare the discrete sampled outcomes to the actual quoted line. Integer lines can push; half-point lines cannot. Over and under estimates use the same seed/distribution, so their mass plus push mass partitions one.

Whole-vector resampling preserves empirical covariance (with a shared perturbation); independent points/rebounds/assists assumptions are avoided. It does **not** establish that future correlations or tails will match historical data. No per-matchup opponent defensive effect is currently fitted for player props; that future input is marked unimplemented rather than secretly applying arbitrary coefficients.

PRA is the sum of the sampled P/R/A vector. Double-/triple-double events count at least 2/3 categories reaching 10 across **points, rebounds, assists, steals and blocks**. Missing STL/BLK blocks those markets, rather than treating missing categories as zeros.

### Live player props

Require a live game and fresh actual player minutes/stats (maximum 90 seconds). Remaining expected minutes are bounded by both the pregame opportunity estimate minus accrued minutes and game-time remaining × projected minutes / 48. Final stat samples are accrued actual values plus sampled remaining production. Overtime changes the team-market horizon, but player rotations and possession-level state are not modeled: live player props are suppressed during overtime. A zero remaining horizon waits for an explicit next period/final status, and already-achieved full-game thresholds are not treated as new edges. Expired forecasts clear sizing fields too.

This is an especially weak live baseline: substitutions, fouls, usage changes, blowouts, injury restrictions, possessions and book latency are not modeled. Missing/expired accrued data disables probability/EV instead of substituting pregame averages.

## Moneyline

Require offense, defense and pace for both teams and at least 12 historical team games.

- Matchup pace = average home/away pace.
- Baseline home points = pace × `(home offense + away defense)/200 + 1.15`.
- Baseline away points = pace × `(away offense + home defense)/200 − 1.15`.
- Without Elo: expected margin = baseline home − away points + `0.5 × clipped rest differential`.
- With Elo: margin = `0.7 × rating-derived margin + 0.3 × (Elo difference/28 + 2.3) + 0.5 × rest differential`.
- Rest differential is clipped to ±3 days. Home court is a fixed 2.3-point baseline.
- Use a normal margin distribution with empirical home-team margin SD clipped to 9–18 points. Win probability is `Phi(expected margin / SD)`; away probability is its complement.

Elo starts at 1500 within the fetched historical window, uses K=20 and a 65-rating home adjustment, and updates chronologically only after paired resolved games. This is **windowed**, not a complete multiseason trained rating, and does not model roster transitions or seasonal regression. Rating/Elo features partially overlap; the mixture is heuristic.

Live moneyline conditions expected margin on the actual current score difference and the remaining fraction of the game. SD scales with sqrt(remaining fraction), with a 1.5-point floor. Ties are treated through a continuous winner baseline; explicit overtime-resolution dynamics are not learned.

## Team totals

Use the above team mean with historical team point SD (9–18). Live totals add accrued actual score to expected remaining points. Integer/half-point settlement uses a normal distribution with discrete continuity boundaries:

- `P(under) = Phi((ceil(line) − 0.5 − mean)/SD)`
- `P(over) = 1 − Phi((floor(line) + 0.5 − mean)/SD)`
- On integer lines, `P(push) = 1 − P(over) − P(under)`.

This discretized normal baseline is not a calibrated team-scoring model.

Live player overtime rotations are not modeled: those forecasts are suppressed. A zero remaining horizon awaits an explicit next period/final status, and already-achieved full-game thresholds are not offered as new edges. Expired forecasts also clear sizing fields.

## First basket

No guessed probabilities from PPG or scoring rate. Require:

- A pregame, non-preseason event.
- Exactly 10 starters confirmed for the target event (`starterGameId`) across both teams, no contradictory reported-out starter.
- At least 20 historical first-made-field-goal observations for every starter.

Jeffreys-smoothed historical frequency `(wins + 0.5)/(games + 1)` is normalized across the complete field. “No” is the complement. Dated starter opportunities can come from the optional local PBP archive; the engine counts only observations strictly before the target date (never the target day or future games). Legacy explicit aggregate counts are also supported, but their cutoff cannot be independently checked. The public NBA/ESPN adapters do **not** produce a complete historical first-basket corpus automatically, and no actual corpus is bundled. Historical box-score starters do not confirm a new event's lineup. Frequency normalization is a matchup-independent approximation and does not account for tip-off possession, opening plays or lineup interactions.

Settlement is **first made field goal** (not first free throw/point). Only import matching prices/rules. Live first-basket markets are disabled once a game starts.

## Historical archive inputs

See [HISTORICAL_DATA.md](HISTORICAL_DATA.md). Raw all-season play-by-play remains outside the runtime feature workspace. Recent complete regular-season box-score vectors enter the existing bootstrap, not a new trained ML model. First-FG events become dated historical-start opportunities, with a separate current `lineups` import. Verified opening/final-score/period checks reject incomplete data rather than impute missing fields. Local archive data is still user-supplied/unverified.

Team fallback possessions are the average of both teams' `FGA − ORB + TOV + 0.44 × FTA`; pace scales to 48 minutes, including overtime adjustment. Offense/defense use points per estimated possession. These are explicit approximations, not official possession counts or coefficients fitted to all history. Fresh complete public ratings/overlapping logs and current roster/live fields take priority. Explicit user feature overrides remain authoritative. Historical environment timestamps stay historical, so a stale archive cannot pass the 48-hour live-data guard just because it was exported today.

## EV, fair prices and sizing

Bookmaker prices are displayed/input as **implied percentages** (including margin), not model forecasts. A percentage `o` means `q = o/100`, decimal payout `d = 1/q`, and `EV percent = 100 × (P(win)/q + P(push) − 1)`. Calculation precision is preserved even when the UI rounds display to two decimal places.

Legacy American odds `a` remain accepted at the import/provider boundary:

- If positive: decimal `d = 1 + a/100`.
- If negative: decimal `d = 1 + 100/abs(a)`.
- `EV percent = 100 × (P(win) × d + P(push) − 1)`.
- This is expected **profit** per $100 staked; displayed expected gross return is `$100 + EV`.

No-vig implied probability is `implied_side/(implied_side + implied_opposite)`. Only same-game/market/subject/line/book opposite selections, both fresh and at most 90 seconds apart, qualify. Model edge compares conditional-on-no-push win probability with that no-vig benchmark. No matching opposite quote means no fair-price/edge figure.

Optional quarter-Kelly uses `(b×P(win) − P(loss))/(b×(P(win)+P(loss))) × 0.25`, with `b=d−1`, clipped to 0–2% of the illustrative bankroll. It is **off by default** and not actionable advice. Uncalibrated inputs make Kelly particularly dangerous.

## Samples are not confidence

Effective historical N is `(sum weights)^2 / sum(weights^2)`. A Wilson 95% sampling interval uses that N, **not 8,192 simulated draws**. For teams/first basket, historical counts are used. This interval ignores model error, correlation across games, source errors, selection bias and nonstationarity. “Larger/moderate/small sample” is a sample-size label, not a confidence grade.

The lower-bound EV is a sampling sensitivity calculation, not proof that an edge is robust.

## Suppression and data guards

No EV for absent, suspended, expired or future-dated prices; no probability for final/postponed/cancelled games, unconfirmed live transition after start, unsupported settlement, preseason, missing history/pace, reported-out players or stale live stats. Official/imported team environments older than 48 hours are suppressed in live-data mode. Historical player samples older than 210 days are rejected; >45 days is explicitly warned.

All data timestamps are UTC. The browser formats starts in the viewer's timezone. Imported odds timestamps are retained across refresh/restart, not overwritten by retrieval time. ESPN moneylines often have no reliable book-last-update time: retrieval age is shown and a verification warning is mandatory.

## Backtesting and market comparison CLI

`--backtest` scores **supplied predictions**; it does not reconstruct historical features, train the estimator, or independently prove that timestamps/data are authentic. `predictedAt` must precede `startsAt`. Optional `pushProbability` affects EV selection. Brier/log loss score outcomes conditional on no push; actual pushes are refunded in flat-stake ROI and excluded from binary scoring.

For a direct model-vs-market comparison, include a closing market forecast on **every** observation, plus a unique `gameId`, `closingAt` and (recommended) a `market` label. `closingAt` must be at or after `predictedAt` and before `startsAt`. Supply exactly one of:

- `closingNoVigProbability`: the closing market's already de-vigged probability for the selected outcome, conditional on no push; or
- `closingOddsPercent` and `closingOppositeOddsPercent`: the two closing implied percentages, from the same book/source, exact market/line and timestamp. The scorer computes `selected / (selected + opposite)`.

Example row fields (the sample is fictional):

```json
{
  "gameId": "historical-game-id",
  "market": "points",
  "probability": 0.56,
  "pushProbability": 0.02,
  "oddsPercent": 52.38,
  "predictedAt": "2026-10-01T20:00:00Z",
  "closingAt": "2026-10-01T23:55:00Z",
  "closingOddsPercent": 54.1,
  "closingOppositeOddsPercent": 47.8,
  "startsAt": "2026-10-02T00:00:00Z",
  "result": "win"
}
```

The report compares paired, push-conditional Brier and log loss against the closing market overall and by market. Negative model-minus-market loss favors the model; positive skill score means the model's loss was proportionally lower. It also gives an approximate 95% normal interval clustered by `gameId` only when at least 30 resolved game clusters exist; smaller samples get no interval. That interval does not correct for repeated-team/time dependence, model selection, bad source data or leakage. All-or-none benchmark fields deliberately reject partial market samples. Without benchmark fields, the report explicitly says `not_provided`; ordinary ROI is not evidence that the model beat the market.

A credible performance claim still requires a timestamped historical feature/obtainable-price corpus, strictly walk-forward predictions, held-out calibration, realistic settlement/limits/latency, the complete predeclared set of picks (not winners cherry-picked after the fact), closing-line comparisons and adequate independent samples. No such real benchmark corpus or result is included here.
